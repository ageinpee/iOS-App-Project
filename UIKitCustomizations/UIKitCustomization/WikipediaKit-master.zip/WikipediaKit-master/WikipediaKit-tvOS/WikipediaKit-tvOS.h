//
//  WikipediaKit-tvOS.h
//  WikipediaKit-tvOS
//
//  Created by Frank Rausch on 2017-03-21.
//  Copyright © 2017 Raureif GmbH / Frank Rausch. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WikipediaKit-tvOS.
FOUNDATION_EXPORT double WikipediaKit_tvOSVersionNumber;

//! Project version string for WikipediaKit-tvOS.
FOUNDATION_EXPORT const unsigned char WikipediaKit_tvOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WikipediaKit_tvOS/PublicHeader.h>


