//
//  WikipediaKit.h
//  WikipediaKit
//
//  Created by Frank Rausch on 2017-03-21.
//  Copyright © 2017 Raureif GmbH / Frank Rausch. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for WikipediaKit.
FOUNDATION_EXPORT double WikipediaKitVersionNumber;

//! Project version string for WikipediaKit.
FOUNDATION_EXPORT const unsigned char WikipediaKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WikipediaKit/PublicHeader.h>


