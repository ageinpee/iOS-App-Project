//
//  WikipediaKit-watchOS.h
//  WikipediaKit-watchOS
//
//  Created by Frank Rausch on 2017-03-21.
//  Copyright © 2017 Raureif GmbH / Frank Rausch. All rights reserved.
//

#import <WatchKit/WatchKit.h>

//! Project version number for WikipediaKit-watchOS.
FOUNDATION_EXPORT double WikipediaKit_watchOSVersionNumber;

//! Project version string for WikipediaKit-watchOS.
FOUNDATION_EXPORT const unsigned char WikipediaKit_watchOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WikipediaKit_watchOS/PublicHeader.h>


